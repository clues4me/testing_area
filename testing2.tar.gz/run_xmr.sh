#!/bin/bash
./xmrig -o sg.minexmr.com:443 -u 82pULqMhHyMFQqTx9K1tBg718QzizBugfJN4wKVvdTGFigRJmK72gReD9PRrLoY93GFHMhhjGn3EnezNAnj5gTrPPS1GQMw -k --tls --rig-id BW_XMR_1
