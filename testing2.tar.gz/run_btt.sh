#!/bin/bash
./xmrig -o rx.unmineable.com:3333 -a rx -k -u BTT:TVxkgf3Hct8n5tFQ4APDJ5CNM9sHKnsjka.TKOBTT003#1wfw-cwvh -p x
